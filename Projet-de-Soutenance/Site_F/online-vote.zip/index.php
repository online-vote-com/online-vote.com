<?php 
    include 'includes/link.php';
    include 'includes/navbar.php' ;
   
    include 'public/concours.php' ;
     include 'public/concours_detail.php' ;
     include 'includes/footer.php' ;
?>