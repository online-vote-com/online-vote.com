<div  id="section-stats" class="content-section" style="display: none;">
    <div class="stats-header">
        Statistiques du concours de : Nom concours
    </div>

    <div class="stats-subheader">
        <div class="col">Rang</div>
        <div class="col">Nom candidat</div>
        <div class="col">Profil</div>
        <div class="col">Nombre de vote</div>
    </div>

    <div class="stats-body">
        <div class="stats-row">
            <div class="col">01</div>
            <div class="col-name">Arthur Chakoualeu</div>
            <div class="col"><img src="profil.jpg" class="avatar-circle"></div>
            <div class="col">1000</div>
        </div>
        <div class="stats-row">
            <div class="col">02</div>
            <div class="col-name">Arthur Chakoualeu</div>
            <div class="col"><img src="profil.jpg" class="avatar-circle"></div>
            <div class="col">1000</div>
        </div>
        </div>

    <hr class="separator-line">

    <div class="stats-footer">
        <button class="btn-pdf">Exporter le PDF</button>
        <div class="pagination-controls">
            <span class="arrow">&lt;</span>
            <span class="page-num active">1</span>
            <span class="page-num">10</span>
            <span class="arrow">&gt;</span>
        </div>
    </div>

    <div class="total-amount">
        Montant total après déduction : 000 FCFA
    </div>
</div>