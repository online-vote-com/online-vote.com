<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kamer-vote</title>


    <link rel="stylesheet" href="../assets/css/admin.css">
    <link rel="stylesheet" href="../assets/css/color.css">
     <link rel="stylesheet" href="../assets/css/tableau.css">
    <link rel="stylesheet" href="../assets/css/grid-card.css">
    <link rel="stylesheet" href="../assets/css/navbar.css">
     <link rel="stylesheet" href="../assets/css/accueil.css">
</head>
<body>