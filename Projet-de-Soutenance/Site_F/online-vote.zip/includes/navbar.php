<link rel="stylesheet" href="assets/css/navbar.css">

<header class="main-header">
    <div class="header-container">
        <div class="logo">
            <span class="online">O</span><span class="line-text">NLINE</span>
            <span class="vote-tag">vote</span>
        </div>

        <nav class="nav-menu">
            <ul>
                <li><a href="#">Acceuil</a></li>
                <li><a href="#">A propos</a></li>
                <li><a href="#">Contact</a></li>
                <li><a href="#">concours</a></li>
            </ul>
        </nav>

        <div class="header-actions">
            <a href="#" class="btn-connect">Se connecter</a>
        </div>
    </div>
</header>
