<?php define('BASE_URL', 'http://localhost/Projet-de-Soutenance/Site_F/') ?>

    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Online Vote</title>
            <!-- Google Fonts -->
     <link rel="stylesheet" href="<?= BASE_URL ?>https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap">
    <!-- CSS -->
    <link rel="stylesheet" href="<?= BASE_URL ?>assets/css/color.css">
    <link rel="stylesheet" href="<?= BASE_URL ?>assets/css/tableau.css">
    <link rel="stylesheet" href="<?= BASE_URL ?>assets/css/sidebar.css">
    <link rel="stylesheet" href="<?= BASE_URL ?>assets/css/grid-card.css">
    <link rel="stylesheet" href="<? BASE_URL ?>assets/css/formulaire_nouveau.css">
   <link rel="stylesheet" href="<? BASE_URL ?>assets/css/navbar.css">

    <script src="<? BASE_URL ?>assets/js/modal.js"></script>
    </head>
